#pragma once
#include "Game.h"
#include "ChessSquare.h"
#include <string>
#include <vector>
#include <algorithm>

//
// the classic game of chess
//
enum ChessPiece {
    Pawn = 1,
    Knight,
    Bishop,
    Rook,
    Queen,
    King
};

//
// the main game class
//
class Chess : public Game
{
public:
    Chess();
    ~Chess();
    
    enum MoveType{ DEFAULT, ENPASSANT, QSCASTLE, KSCASTLE, PAWN2};
    struct HasMoved{
        bool WKing = false;
        bool WRook = false;
        bool BKing = false;
        bool BRook = false;
    };
    //ADDED STRUCT MOVE
    struct Move{
        std::string from;
        std::string to;
        Chess::MoveType moveType = DEFAULT;
    };

    // set up the board
    void        setUpBoard() override;

    Player*     checkForWinner() override;
    bool        checkForDraw() override;
    std::string initialStateString() override;
    std::string stateString() const override;
    void        setStateString(const std::string &s) override;
    bool        actionForEmptyHolder(BitHolder &holder) override {return false; }
    bool        canBitMoveFrom(Bit& bit, BitHolder& src) override;
    bool        canBitMoveFromTo(Bit& bit, BitHolder& src, BitHolder& dst) override;
    void        bitMovedFromTo(Bit& bit, BitHolder& src, BitHolder& dst) override;
    bool	    clickedBit(Bit& bit) override;
    void        stopGame() override;
    int         evaluateBoard(const char* stateString);
    int         evalBoard(std::string state, char color);

    BitHolder &getHolderAt(const int x, const int y) override { return _grid[y][x]; }
    ChessSquare &getHolderAtC(const int x, const int y) { return _grid[y][x]; }
    
    //ADDED METHODS
    bool moveIsEnPassant(std::string board, Chess::Move move);
    bool moveIsQueenSideCastle(std::string board, Chess::Move move);
    bool moveIsKingSideCastle(std::string board, Chess::Move move);
    void printMove(Chess::Move move);
    void printMoves();
    void printStateString(std::string state);
    std::vector<std::pair<int,int>> validMovesForPiece(char piece, ChessSquare& src);
    std::vector<std::pair<int,int>> _highlightedMoves;
    std::string pieceNotation(int row, int col) const;
    std::vector<Chess::Move> genValMoves(std::string state, char currPlayer, Chess::HasMoved stats, Chess::Move lastMove, bool recordLastMove = true);
    bool moveVal(int r, int c, char p, std::string board);
    void linMoves(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    void diagMoves(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genKing(std::vector<Move>& moves, int row, int col, char piece, std::string board, Chess::HasMoved stats);
    bool genQueen(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genRook(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genBishop(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genKnight(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genPawn(std::vector<Move>& moves, int row, int col, char piece, std::string board, Chess::Move lastMove);
    bool isKingInCheck(std::string state, char color, std::vector<Chess::Move> moves);
    std::vector<Chess::Move> generateMoves(std::string state, char color, Chess::HasMoved stats, Chess::Move lastMove);
    bool isKingInCheck(int row, int col, char color);
    void setAI(char ai){
        AI = ai == 'W' ? 'W' : 'B';
        nonAI = ai == 'W' ? 'B' : 'W';
        std::cout<<"ai: "<<AI<<" nonAI: "<<nonAI<<std::endl;
    }
    //CHESS AI FUNCTIONS
    std::string enactMove(std::string state, char currPlayer, Chess::Move move);
    void AIMoveBit(Chess::Move& move);
    void updateAI();
    //bool customCompare(const std::pair<int, Chess::Move>& a, const std::pair<int, Chess::Move>& b);
    //bool isCheckmate(char color) {return false;};
    //bool isStalemate(char color) {return false;};
    int minimaxAlphaBetaSorted(std::string state, int depth, bool isMaximizingPlayer, int alpha, int beta, Chess::HasMoved stats, Chess::Move lastMove);
private:
    const char  bitToPieceNotation(int row, int column) const;
    const char  gameTagToPieceNotation(int gameTag) const;
    std::string indexToNotation(int row, int col);
    int rowColToIndex(int row, int col);
    int notationToIndex(std::string notation);
    int notationToRow(std::string notation);
    int notationToCol(std::string notation);
    std::pair<int,int> indexToNotation(std::string notation);

    Bit *       PieceForPlayer(const int playerNumber, ChessPiece piece);
    char _currPlayer;
    ChessSquare         _grid[8][8];
    std::vector<Move> _moves;
    Chess::Move _bestMove;
    Move _lastMove;
    char _lastPiece;
    Move _lastEnPassantMove;
    Move _lastCastle;
    Chess::HasMoved _stats;
    //priv CHESS AI vars
    char AI = 'W'; //color the AI is
    char nonAI = 'B';
    bool _AIInProgress = false;
    bool _AIDone = false;
    int maxDepth = 3; //max depth minmax search will do

    // piece square tables for every piece (from chess programming wiki)
    const int pawnTable[64] = {
        0,  0,  0,  0,  0,  0,  0,  0,
        50, 50, 50, 50, 50, 50, 50, 50,
        10, 10, 20, 30, 30, 20, 10, 10,
        5,  5, 10, 25, 25, 10,  5,  5,
        0,  0,  0, 20, 20,  0,  0,  0,
        5, -5,-10,  0,  0,-10, -5,  5,
        5, 10, 10,-20,-20, 10, 10,  5,
        0,  0,  0,  0,  0,  0,  0,  0
    };
    const int knightTable[64] = {
        -50,-40,-30,-30,-30,-30,-40,-50,
        -40,-20,  0,  0,  0,  0,-20,-40,
        -30,  0, 10, 15, 15, 10,  0,-30,
        -30,  5, 15, 20, 20, 15,  5,-30,
        -30,  0, 15, 20, 20, 15,  0,-30,
        -30,  5, 10, 15, 15, 10,  5,-30,
        -40,-20,  0,  5,  5,  0,-20,-40,
        -50,-40,-30,-30,-30,-30,-40,-50,
     };
    const int rookTable[64] = {
    0,  0,  0,  0,  0,  0,  0,  0,
    5, 10, 10, 10, 10, 10, 10,  5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    0,  0,  0,  5,  5,  0,  0,  0
    };
    const int queenTable[64] = {
    -20,-10,-10, -5, -5,-10,-10,-20,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -10,  0,  5,  5,  5,  5,  0,-10,
     -5,  0,  5,  5,  5,  5,  0, -5,
      0,  0,  5,  5,  5,  5,  0, -5,
    -10,  5,  5,  5,  5,  5,  0,-10,
    -10,  0,  5,  0,  0,  0,  0,-10,
    -20,-10,-10, -5, -5,-10,-10,-20
    };
    const int kingTable[64] = {
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -20,-30,-30,-40,-40,-30,-30,-20,
    -10,-20,-20,-20,-20,-20,-20,-10,
    20, 20,  0,  0,  0,  0, 20, 20,
    20, 30, 10,  0,  0, 10, 30, 20
    };
    const int kingEndTable[64] = {
    -50,-40,-30,-20,-20,-30,-40,-50,
    -30,-20,-10,  0,  0,-10,-20,-30,
    -30,-10, 20, 30, 30, 20,-10,-30,
    -30,-10, 30, 40, 40, 30,-10,-30,
    -30,-10, 30, 40, 40, 30,-10,-30,
    -30,-10, 20, 30, 30, 20,-10,-30,
    -30,-30,  0,  0,  0,  0,-30,-30,
    -50,-30,-30,-30,-30,-30,-30,-50
    };
    const int bishopTable[64] = {
    -20,-10,-10,-10,-10,-10,-10,-20,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -10,  0,  5, 10, 10,  5,  0,-10,
    -10,  5,  5, 10, 10,  5,  5,-10,
    -10,  0, 10, 10, 10, 10,  0,-10,
    -10, 10, 10, 10, 10, 10, 10,-10,
    -10,  5,  0,  0,  0,  0,  5,-10,
    -20,-10,-10,-10,-10,-10,-10,-20
    };
};