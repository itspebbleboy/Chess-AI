#pragma once
#include "Game.h"
#include "ChessSquare.h"
#include <string>
#include <vector>

//
// the classic game of chess
//
enum ChessPiece {
    Pawn = 1,
    Knight,
    Bishop,
    Rook,
    Queen,
    King
};

//
// the main game class
//
class Chess : public Game
{
public:
    Chess();
    ~Chess();

    //ADDED STRUCT MOVE
    struct Move{
        std::string from;
        std::string to;
    };

    // set up the board
    void        setUpBoard() override;

    Player*     checkForWinner() override;
    bool        checkForDraw() override;
    std::string initialStateString() override;
    std::string stateString() const override;
    void        setStateString(const std::string &s) override;
    bool        actionForEmptyHolder(BitHolder &holder) override {return false; }
    bool        canBitMoveFrom(Bit& bit, BitHolder& src) override;
    bool        canBitMoveFromTo(Bit& bit, BitHolder& src, BitHolder& dst) override;
    void        bitMovedFromTo(Bit& bit, BitHolder& src, BitHolder& dst) override;
    bool	    clickedBit(Bit& bit) override;
    void        stopGame() override;
    int         evaluateBoard(const char* stateString);

    BitHolder &getHolderAt(const int x, const int y) override { return _grid[y][x]; }
    ChessSquare &getHolderAtC(const int x, const int y) { return _grid[y][x]; }
    
    //ADDED METHODS
    void printMove(Chess::Move move);
    void printMoves();
    std::vector<std::pair<int,int>> validMovesForPiece(char piece, ChessSquare& src);
    std::vector<std::pair<int,int>> _highlightedMoves;
    std::string pieceNotation(int row, int col) const;
    std::vector<Chess::Move> genValMoves();
    bool moveVal(int r, int c, char p, std::string board);
    void linMoves(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    void diagMoves(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genKing(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genQueen(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genRook(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genBishop(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genKnight(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool genPawn(std::vector<Move>& moves, int row, int col, char piece, std::string board);
    bool isKingInCheck(std::string state, char color, std::vector<Chess::Move> moves);
    std::vector<Move> generateMoves(std::string state, char color);
    bool isKingInCheck(int row, int col, char color);

private:
    const char  bitToPieceNotation(int row, int column) const;
    const char  gameTagToPieceNotation(int gameTag) const;
    std::string indexToNotation(int row, int col);
    int rowColToIndex(int row, int col);
    int notationToIndex(std::string notation);
    int notationToRow(std::string notation);
    int notationToCol(std::string notation);
    std::pair<int,int> indexToNotation(std::string notation);

    Bit *       PieceForPlayer(const int playerNumber, ChessPiece piece);
    char currPlayer;
    ChessSquare         _grid[8][8];
    std::vector<Move> _moves;
    std::vector<Bit *> _activeWPieces;
    std::vector<Bit *> _activeBPieces;
};
