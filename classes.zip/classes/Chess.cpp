#include "Chess.h"
#include "ChessSquare.h"

const int pieceSize = 64;
//
// add a helper to Square so it returns out FEN chess notation in the form p for white pawn, K for black king, etc.
// this version is used from the top level board to record moves
//
const char Chess::bitToPieceNotation(int row, int column) const
{
    if (row < 0 || row >= 8 || column < 0 || column >= 8) {
        return '0';
    }

    const char *bpieces = { "?PNBRQK" };
    const char *wpieces = { "?pnbrqk" };
    unsigned char notation = '0';
    Bit *bit = _grid[row][column].bit();
    if (bit) { // 0-128 = white pieces, 128-
        notation = bit->gameTag() < 128 ? wpieces[bit->gameTag()] : bpieces[bit->gameTag()&127];
    } else {
        notation = '0';
    }
    return notation;
}

std::string Chess::pieceNotation(int row, int col) const{
    const char *pieces = {"?PNBRQK"};
    std::string notation = "";
    Bit *bit = _grid[row][col].bit();
    if(bit){
        notation += bit->gameTag() <128 ? "W" : "B";
        notation += pieces[bit->gameTag()&127];
    }else{
        notation = "00";
    }
    return notation; // notation is /COLOR/ & then the /PIECE CHAR/
}

const char Chess::gameTagToPieceNotation(int gameTag) const{
    const char *bpieces = { "?PNBRQK" };
    const char *wpieces = { "?pnbrqk" };
    return gameTag < 128 ? wpieces[gameTag] : bpieces[gameTag&127];
}

// Convert row and column index to chess notation
std::string Chess::indexToNotation(int row, int col) 
{
    return std::string(1, 'a' + col) + std::string(1, '8' - row);
}

int Chess::rowColToIndex(int row, int col){
    return row*8+col;
}
int Chess::notationToIndex(std::string notation) 
{
    return (8*(8-(int)(notation[1]-48)) + (int)(notation[0]-97));
}

int Chess::notationToRow(std::string notation){
    return (8-(notation[1]-48));
}
int Chess::notationToCol(std::string notation){
    return (notation[0]-97);
}
void Chess::printMove(Chess::Move move){
    std::cout<< "p: " << currPlayer << " " <<move.from<<" -> "<<move.to<<std::endl;
}
void Chess::printMoves(){
    std::string lastSrc = "";
    for(Move move: _moves){
        if(lastSrc!= move.from){
            lastSrc=move.from;
            std::cout<<std::endl<<move.from<<" -> "<<move.to<<", ";
        }else{
            std::cout<<" -> "<<move.to;
        }
    }
    std::cout<<std::endl;
}

Chess::Chess()
{
}

Chess::~Chess()
{
}

//
// make a chess piece for a player
//
Bit* Chess::PieceForPlayer(const int playerNumber, ChessPiece piece)
{
    const char *pieces[] = { "pawn.png", "knight.png", "bishop.png", "rook.png", "queen.png", "king.png" };

    Bit *bit = new Bit();
    // should possibly be cached from player class?
    const char *pieceName = pieces[piece - 1];
    std::string spritePath = std::string("chess/") + (playerNumber == 0 ? "b_" : "w_") + pieceName;
    bit->LoadTextureFromFile(spritePath.c_str());
    bit->setOwner(getPlayerAt(playerNumber));
    bit->setSize(pieceSize,pieceSize);
    return bit;
}

void Chess::setUpBoard()
{
    const ChessPiece initialBoard[2][8] = {
        {Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook},  // 1st Rank
        {Pawn, Pawn, Pawn, Pawn, Pawn, Pawn, Pawn, Pawn}  // 2nd Rank
    };

    setNumberOfPlayers(2);
    _gameOptions.rowX = 8;
    _gameOptions.rowY = 8;
    for (int y=0; y<_gameOptions.rowY; y++) {
        for (int x=0; x<_gameOptions.rowX; x++) {
            _grid[y][x].initHolder(ImVec2((float)(pieceSize*x + pieceSize),(float)(pieceSize*y + pieceSize)), "boardsquare.png", x, y);
            _grid[y][x].setGameTag(0);
            _grid[y][x].setSize(pieceSize,pieceSize);
            _grid[y][x].setNotation( indexToNotation(y, x) );
        }
    }

    for (int rank=0; rank<2; rank++) {
        for (int x=0; x<_gameOptions.rowX; x++) {
            ChessPiece piece = initialBoard[rank][x];
            Bit *bit = PieceForPlayer(0, initialBoard[rank][x]);
            bit->setPosition(_grid[rank][x].getPosition());
            bit->setParent(&_grid[rank][x]);
            bit->setGameTag( piece + 128);
            _grid[rank][x].setBit( bit );

            bit = PieceForPlayer(1, initialBoard[rank][x]);
            bit->setPosition(_grid[7-rank][x].getPosition()); // 8th & 7th row
            bit->setParent(&_grid[7-rank][x]);
            bit->setGameTag( piece );
            _grid[7-rank][x].setBit( bit );
        }
    }

    if (gameHasAI()) {
        setAIPlayer(AI_PLAYER);
    }
    currPlayer = 'W'; 
    _moves = genValMoves();
    printMoves();

    startGame();
}

//return true if it is legal for the given bit to be moved from its current holder
bool Chess::canBitMoveFrom(Bit& bit, BitHolder& src)
{
    //Generate list of possible locations for a bit to move from 
    //if there's a valid move for the piece, it can move
    for (std::pair<int,int> pair : _highlightedMoves) {
        const int col = pair.first, row = pair.second;
        getHolderAtC(col, row).setMoveHighlighted(false);
        (static_cast<ChessSquare&>(getHolderAt(col, row))).setMoveHighlighted(false);
    }
    ChessSquare &srcSquare = static_cast<ChessSquare&>(src);
    char pieceType = bitToPieceNotation(srcSquare.getRow(),srcSquare.getColumn());
    if((std::islower(pieceType)&&currPlayer=='B') ||(std::isupper(pieceType)&&currPlayer =='W')){
        return false;
    }
    std::vector<Chess::Move> pMoves;
    std::string currN = indexToNotation(srcSquare.getRow(),srcSquare.getColumn());
    for(Chess::Move move : _moves){
        if (move.from == currN){
            pMoves.push_back(move);
            int x = notationToCol(move.to), y = notationToRow(move.to);
            _highlightedMoves.emplace_back(std::make_pair(x, y));
            getHolderAtC(x,y).setMoveHighlighted(true);
        }
    }
    if(pMoves.empty()){
        return false;
    }
    return true;
}

bool Chess::clickedBit(Bit& bit)
{
    return true;
}

bool Chess::canBitMoveFromTo(Bit& bit, BitHolder& src, BitHolder& dst)
{
    ChessSquare sbit = static_cast<ChessSquare&>(src);
    ChessSquare dbit = static_cast<ChessSquare&>(dst);
    std::string sourceN = indexToNotation(sbit.getRow(),sbit.getColumn());
    std::string destN = indexToNotation(dbit.getRow(),dbit.getColumn());
    for(Chess::Move move : _moves){
        if (move.from == sourceN && move.to == destN){ 
            return true;
        }
    }
    return false;
}

bool Chess::moveVal(int r, int c, char p, std::string board){ 
    //p is the char representing the orignal piece and r & c are the new proposed location
    if (r >= 0 && r < 8 && c >= 0 && c < 8) {
        // Check if the square is empty or contains an opponent's piece
        if (board[r * 8 + c] == '0' || (islower(p) && isupper(board[r * 8 + c])) || (isupper(p) && islower(board[r * 8 + c]))) {
            return true;
        }
    }
    return false;
}

bool Chess::genKing(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    // Possible moves for a king
    static const int movesRow[]= {-1, -1, -1,  0, 0,  1, 1, 1};
    static const int movesCol[]= {-1,  0,  1, -1, 1, -1, 0, 1};
    // Check each possible move and highlight if it's a valid move
    for (int i =0; i<8; i++) {
        int r = row + movesRow[i];
        int c = col + movesCol[i];

        if(moveVal(r, c, piece, board)){ //valid in the 1st sense, not looking into pinning or anything
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }
    }
    return false;
}

void Chess::linMoves(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    // Up
    for (int i = 1; row - i >= 0; ++i) {
        int r = row - i;
        int c = col;
        char targetPiece = board[(row - i) * 8 + col];
        
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if (targetPiece != '0'){
            break;
        }
    }
    // Down
    for (int i = 1; row + i < 8; ++i) {
        int r = row + i;
        int c = col;
        char targetPiece = board[(row + i) * 8 + col];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if (targetPiece != '0'){
            break;
        }
    }
    // Left
    for (int i = 1; col - i >= 0; ++i) {
        int r = row;
        int c = col - i;
        char targetPiece = board[row * 8 + (col - i)];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if (targetPiece != '0'){
            break;
        }
    }
    // Right
    for (int i = 1; col + i < 8; ++i) {
        int r = row;
        int c = col + i;
        char targetPiece = board[row * 8 + (col + i)];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if (targetPiece !='0'){
            break;
        }
    }
}

void Chess::diagMoves(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    // Top-left
    for (int i = 1; row - i >= 0 && col - i >= 0; ++i) {
        int r = row - i, c = col - i;
        char targetPiece = board[(row - i) * 8 + (col - i)];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if (targetPiece !='0'){
            break;
        }
    }
    // Top-right
    for (int i = 1; row - i >= 0 && col + i < 8; ++i) {
        int r = row - i, c = col + i;
        char targetPiece = board[(row - i) * 8 + (col + i)];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if(targetPiece != '0'){
            break;
        }
    }
    // Bottom-left
    for (int i = 1; row + i < 8 && col - i >= 0; ++i) {
        int r = row + i, c = col - i;
        char targetPiece = board[(row + i) * 8 + (col - i)];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if(targetPiece != '0'){
            break;
        }
    }
    // Bottom-right
    for (int i = 1; row + i < 8 && col + i < 8; ++i) {
        int r = row + i, c = col + i;
        char targetPiece = board[(row + i) * 8 + (col + i)];
        if (targetPiece == '0' || (islower(piece) && isupper(targetPiece)) || (isupper(piece) && islower(targetPiece))) {
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }if(targetPiece != '0'){
            break;
        }
    }
}

bool Chess::genQueen(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    linMoves(moves, row, col, piece, board);
    diagMoves(moves, row, col, piece, board);
    return false;
}

bool Chess::genRook(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    linMoves(moves, row, col, piece, board);
    return false;
}

bool Chess::genBishop(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    diagMoves(moves, row, col, piece, board);
    return false;
}

bool Chess::genKnight(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    // Possible moves for a knight
    static const int movesRow[]= {2, 1, -1, -2, -2, -1,  1,  2};
    static const int movesCol[]= {1, 2,  2,  1, -1, -2, -2, -1};

    for(int i = 0; i<8; i++){
        int r = row + movesRow[i];
        int c = col + movesCol[i];

        if(moveVal(r, c, piece, board)){ //valid in the 1st sense, not looking into pinning or anything
            moves.push_back({indexToNotation(row,col),indexToNotation(r,c)});
        }
    }
    return false;
}

bool Chess::genPawn(std::vector<Move>& moves, int row, int col, char piece, std::string board){
    if(piece == 'P'){ //black piece
        if (board[(row+1) * 8 + col] == '0' ) { //if square below free
            moves.push_back({indexToNotation(row,col),indexToNotation(row+1,col)});
            // Check if the pawn is in the original position
            if (row == 1 && (board[(row + 2) * 8 + col] == '0')) { 
                // if pawn's first move & available can move downwards two squares
                moves.push_back({indexToNotation(row,col),indexToNotation(row+2,col)});
            }
        }
        //opponent's piece in the diagonals
        if (col > 0 && std::islower(board[(row + 1) * 8 + col - 1])) {
            moves.push_back({indexToNotation(row,col),indexToNotation(row+1,col-1)});
        }
        if (col < 7 && std::islower(board[(row + 1) * 8 + col + 1])) {
            moves.push_back({indexToNotation(row,col),indexToNotation(row+1,col+1)});
        }
    }
    else{
        if (board[(row-1) * 8 + col] == '0' ) { //if square below free
            moves.push_back({indexToNotation(row,col),indexToNotation(row-1,col)});
            // Check if the pawn is in the original position
            if (row == 6 && (board[(row - 2) * 8 + col] == '0')) { 
                // if pawn's first move & available can move downwards two squares
                moves.push_back({indexToNotation(row,col),indexToNotation(row-2,col)});
            }
        }
        //opponent's piece in the diagonals
        if (col > 0 && std::isupper(board[(row - 1) * 8 + col - 1])) {
            moves.push_back({indexToNotation(row,col),indexToNotation(row-1,col-1)});
        }
        if (col < 7 && std::isupper(board[(row - 1) * 8 + col + 1])) {
            moves.push_back({indexToNotation(row,col),indexToNotation(row-1,col+1)});
        }
    }
    return false;
}

bool Chess::isKingInCheck(std::string state, char color, std::vector<Chess::Move> moves){
    char king = (color == 'W' ? 'k' : 'K');
    int kingIndex = -1;
    for(int i = 0; i< state.length(); i++){
        if (state[i] == king){
            kingIndex = i;
        }
    }
    for(Chess::Move move : moves){
        if(kingIndex == notationToIndex(move.to)){
            return true;
        }
    }
    return false;
}

void Chess::bitMovedFromTo(Bit& bit, BitHolder& src, BitHolder& dst)
{
    for (std::pair<int,int> pair : _highlightedMoves) {
        const int col = pair.first, row = pair.second;
        getHolderAtC(col, row).setMoveHighlighted(false);
        (static_cast<ChessSquare&>(getHolderAt(col, row))).setMoveHighlighted(false);
    }
    currPlayer = currPlayer == 'W' ? 'B' : 'W';
    std::cout<< "CURR PLAYER FOR TURN: "<<currPlayer<<std::endl;
    _moves = genValMoves();
    printMoves();
    endTurn();
}

std::vector<Chess::Move> Chess::genValMoves(){
    std::string state = stateString();
    std::vector<Chess::Move> allMoves = generateMoves(state, currPlayer);
    auto it = allMoves.begin();
    while (it != allMoves.end()) {
        Chess::Move move = *it;
        //simulating move
        std::string newState = state;
        int indexFrom = notationToIndex(move.from);
        newState[notationToIndex(move.to)] = newState[indexFrom];
        newState[indexFrom] = '0';
        //string manipulation for castling & en passant
        std::vector<Chess::Move> oppMoves = generateMoves(newState, currPlayer == 'W' ? 'B' : 'W');
        bool check = isKingInCheck(newState, currPlayer, oppMoves);
        
        if(check){
            it = allMoves.erase(it);
        }
        else{
            ++it;
        }
    }
    return allMoves;
}

std::vector<Chess::Move> Chess::generateMoves(std::string state, char color){
    std::vector<Chess::Move> moves;
    std::string board = state;
    for(int row = 0; row < 8;row++){
        for(int col = 0; col < 8; col++){
            char piece = board[(row*8 + col)];
            //there's a piece there & it belongs to the player inputted
            if(piece != '0' && ( (std::islower(piece)&& color == 'W') || (std::isupper(piece) && color == 'B'))){
                switch(piece){
                    case 'K':
                    case 'k':
                        genKing(moves, row, col, piece, board);
                        break;
                    case 'Q':
                    case 'q':
                        genQueen(moves, row, col, piece, board);
                        break;
                    case 'R':
                    case 'r':
                        genRook(moves, row, col, piece, board);
                        break;
                    case 'B':
                    case 'b':
                        genBishop(moves, row, col, piece, board);
                        break;
                    case 'N':
                    case 'n':
                        genKnight(moves, row, col, piece, board);
                        break;
                    case 'P':
                    case 'p':
                        genPawn(moves, row, col, piece, board);
                        break;
                }
            }
        }
    }
    return moves;
}

//
// free all the memory used by the game on the heap
//
void Chess::stopGame()
{
}

Player* Chess::checkForWinner()
{
    if(_moves.empty()){
        std::cout<<" moves empty "<<std::endl;
        std::string state = stateString();
        std::vector<Chess::Move> oppMoves = generateMoves(state, currPlayer == 'W' ? 'B' : 'W');
        if(isKingInCheck(state, currPlayer, oppMoves)){ //black == 0, white == 1
            return currPlayer == 'W' ? getPlayerAt(1) : getPlayerAt(0);
        }
    }
    return nullptr;
}

bool Chess::checkForDraw(){
    if(_moves.empty()){
        std::string state = stateString();
        std::vector<Chess::Move> oppMoves = generateMoves(state, currPlayer == 'W' ? 'B' : 'W');
        if(isKingInCheck(state, currPlayer, oppMoves)){ //black == 0, white == 1
            return false;
        }
        return true;
    }
    return false;
}

//
// state strings
//
std::string Chess::initialStateString()
{
    return stateString();
}

//
// this still needs to be tied into imguis init and shutdown
// we will read the state string and store it in each turn object
//
std::string Chess::stateString() const
{
    std::string s;
    for (int y=0; y<_gameOptions.rowY; y++) {
        for (int x=0; x<_gameOptions.rowX; x++) {
            s += bitToPieceNotation( y, x );
        }
    }
    return s;
}

//
// this still needs to be tied into imguis init and shutdown
// when the program starts it will load the current game from the imgui ini file and set the game state to the last saved state
//
void Chess::setStateString(const std::string &s)
{
    // not implemented here
}

int Chess::evaluateBoard(const char* stateString)
{
    return 0;
}
